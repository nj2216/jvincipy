# py2html — Python DSL for HTML

**A small, dependency-free Python library to build HTML using Python code (DSL).**

This repository contains a lightweight DSL that exposes HTML & SVG tags as Python callables, a CLI to render `.py` files that produce pages, and a minimal Flask example that serves static assets (CSS/JS). The project is intentionally tiny and readable so you can extend it for templates, server-side rendering, or static site generation.

---

## Project layout

```
py2html_dsl/
├── README.md
├── LICENSE
├── CONTRIBUTING.md
├── CODE_OF_CONDUCT.md
├── pyproject.toml
├── py2html/
│   ├── __init__.py
│   ├── core.py
│   ├── tags.py
│   └── cli.py
├── examples/
│   ├── example.py
│   ├── flask_app.py
│   └── assets/
│       ├── style.css
│       └── script.js
└── tests/
    └── test_basic.py
```

---

## What's included

- `py2html/core.py` — `Tag`, `Markup`, rendering utilities and helpers.
- `py2html/tags.py` — dynamically generated Tag factories for HTML5 + common SVG tags.
- `py2html/cli.py` — CLI to execute a Python file that defines a `page` or `render()` and print/write the generated HTML.
- `examples/` — an example script and a Flask app demonstrating CSS/JS and static assets.
- `tests/` — a minimal pytest file to verify rendering.
- `README.md`, `LICENSE` (MIT), `CONTRIBUTING.md`, and `CODE_OF_CONDUCT.md`.

---

## Quickstart

1. Unzip the project and open a virtual environment:

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -U pytest
```

2. Run the example renderer (prints HTML to stdout):

```bash
python -m py2html.cli examples/example.py --pretty
```

3. Run the Flask demo (requires Flask):

```bash
pip install flask
python examples/flask_app.py
# open http://127.0.0.1:5000/
```

4. Run tests:

```bash
pytest -q
```

---

## Usage patterns & examples

**1) Build pages programmatically**

Create a Python file that constructs a `page` object using tag factories and run it with the CLI or import the module from an app.

**2) CLI rendering**

The CLI expects the executed file to expose either:
- a global `page` (Tag or string), or
- a callable `render()` / `get_page()` that returns a Tag/string.

**3) Flask integration**

Use the Flask example to serve static files from an `assets/` directory and return `page.render(pretty=True)` in a route.

---

## How to extend

- Add more granular helpers (e.g., `Element.with_id()` / `.with_class()` convenience methods).
- Add an optional sanitizer for `Markup` inputs.
- Add an HTML minifier option to CLI (`--minify`).
- Integrate with templating frameworks or provide adapters to popular web frameworks.

---

## Contributing

Please read `CONTRIBUTING.md` for the suggested workflow. In short:

- Fork the repo
- Create a small branch with focused commits
- Add tests for new behavior
- Open a PR with a clear description and any migration notes

---

## License

This project is released under the MIT License — see the `LICENSE` file.

---

## CODE_OF_CONDUCT

A `CODE_OF_CONDUCT.md` has been added to help foster a welcoming community. The project follows the Contributor Covenant v2.1 with a zero-tolerance policy for harassment.
